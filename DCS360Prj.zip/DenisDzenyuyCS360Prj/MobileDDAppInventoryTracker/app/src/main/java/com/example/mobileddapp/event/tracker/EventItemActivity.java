package com.example.mobileddapp.event.tracker;

public class EventItemActivity {
}
