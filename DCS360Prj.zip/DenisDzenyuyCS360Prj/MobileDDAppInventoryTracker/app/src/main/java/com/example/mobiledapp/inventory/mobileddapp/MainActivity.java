package com.example.mobiledapp.inventory.mobileddapp;

import android.app.Activity;

public class MainActivity extends Activity {
}
