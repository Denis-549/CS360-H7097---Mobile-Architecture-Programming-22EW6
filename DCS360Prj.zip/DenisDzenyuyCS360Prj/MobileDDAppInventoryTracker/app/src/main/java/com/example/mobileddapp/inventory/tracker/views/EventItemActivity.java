package com.example.mobileddapp.inventory.tracker.views;

import android.app.Activity;

public class EventItemActivity extends Activity {
}
