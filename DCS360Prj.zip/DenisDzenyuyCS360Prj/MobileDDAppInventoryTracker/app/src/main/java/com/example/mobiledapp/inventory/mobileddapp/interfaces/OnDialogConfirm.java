package com.example.mobiledapp.inventory.mobileddapp.interfaces;

public interface OnDialogConfirm{
    void onDialogConfirm();
}
