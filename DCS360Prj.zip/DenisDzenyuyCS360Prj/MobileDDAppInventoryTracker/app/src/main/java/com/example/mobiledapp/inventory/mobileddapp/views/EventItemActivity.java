package com.example.mobiledapp.inventory.mobileddapp.views;

import android.app.Activity;

public class EventItemActivity extends Activity {
}
