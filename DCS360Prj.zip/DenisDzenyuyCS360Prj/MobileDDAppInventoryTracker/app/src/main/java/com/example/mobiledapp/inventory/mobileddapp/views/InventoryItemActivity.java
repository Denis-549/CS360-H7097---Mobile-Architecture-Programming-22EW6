package com.example.mobiledapp.inventory.mobileddapp.views;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mobiledapp.R;
import com.example.mobiledapp.databinding.ActivityInventoryItemBinding;
import com.example.mobiledapp.inventory.mobileddapp.MainActivity;
import com.google.android.material.snackbar.Snackbar;

public class InventoryItemActivity extends AppCompatActivity {
    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.example.mobiledapp.databinding.ActivityInventoryItemBinding binding = ActivityInventoryItemBinding.inflate(getLayoutInflater());
        view = binding.getRoot();
        setContentView(view);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"#FFFFFFF\">" + getString(R.string.event_type) + "</font>"));

        binding.btnSave.setOnClickListener(view -> showSnack());
    }

    private void showSnack() {
        Snackbar.make(view, "Adding item feature will be implemented soon!", Snackbar.LENGTH_LONG).setAction("OK", view -> startActivity(new Intent(InventoryItemActivity.this, MainActivity.class))).show();
    }

}
